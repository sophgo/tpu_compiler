#define LLVM_REVISION "98be659fb01c25f8bd47f5155bc0167d4d17d9c5"
#define LLVM_REPOSITORY "ssh://charle.hu@10.58.65.11:29418/llvm-project.git"
